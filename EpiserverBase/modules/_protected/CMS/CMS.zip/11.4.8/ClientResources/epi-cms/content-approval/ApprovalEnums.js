//>>built
define("epi-cms/content-approval/ApprovalEnums",{definitionStatus:{enabled:0,disabled:1,inherited:2},reviewerType:{user:0,role:1},status:{inReview:0,approved:1,rejected:2}});