define('epi-cms/nls/widgets_es-es',{
'dgrid/extensions/nls/columnHider':{"popupTriggerLabel":"Mostrar o esconder columnas","popupLabel":"Mostrar o esconder columnas","_localized":{}}
});