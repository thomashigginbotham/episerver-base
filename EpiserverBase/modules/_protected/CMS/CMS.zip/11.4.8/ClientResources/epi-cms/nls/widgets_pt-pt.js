//>>built
define("epi-cms/nls/widgets_pt-pt",{"dgrid/extensions/nls/columnHider":{"popupTriggerLabel":"Show or hide columns","popupLabel":"Show or hide columns","_localized":{}}});