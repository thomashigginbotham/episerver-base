define("epi/patch/patches", [
    "./dijit/form/_FormMixin",
    "./dijit/form/_Spinner",
    "./dijit/_HasDropDown",
    "./dojox/form/uploader/plugins/HTML5",
    "./dijit/tree/Tree",
    "./dijit/_KeyNavContainer",
    "./dojo/dnd/Selector",
    "./dojo/dnd/Moveable",
    "./dojo/store/Observable",
    "./dojo/cldr/nls/nb/gregorian",
    "epi/assign"
], function () {
    return {};
});
