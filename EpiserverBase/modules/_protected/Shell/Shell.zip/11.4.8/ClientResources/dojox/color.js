//>>built
define("dojox/color",["./color/_base"],function(_1){return _1;});